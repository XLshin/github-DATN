<?php

/*
File sepay_webhook.php
File này dùng làm endpoint nhận webhook từ SePay. Mỗi khi có giao dịch SePay sẽ bắn webhook về và chúng ta sẽ lưu thông tin giao dịch vào CSDL. Đồng thời bóc tách ID đơn hàng từ nội dung thanh toán. Sau khi tìm được ID đơn hàng thì cập nhật trạng thái thanh toán của đơn hàng thành đã thanh toán (payment_status=Paid).
 Xem hướng dẫn tạo tích hợp Webhook phía SePay tại https://docs.sepay.vn/tich-hop-webhooks.html
 Endpoint nhận webhook sẽ là https://yourwebsite.tld/sepay_webhook.php
*/

// Include file db_connect.php, file chứa toàn bộ kết nối CSDL
require('db_connect.php');

// Xác thực webhook bằng API Key
$api_key = 'YOUR_API_KEY'; // Lấy API Key từ SePay
$headers = getallheaders();
if (!isset($headers['Authorization']) || $headers['Authorization'] !== ('Apikey ' . $api_key)) {
    http_response_code(401);
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

// Lay du lieu tu webhooks, xem cac truong du lieu tai https://docs.sepay.vn/tich-hop-webhooks.html#du-lieu
$data = json_decode(file_get_contents('php://input'));
if (!is_object($data)) {
    echo json_encode(['success' => false, 'message' => 'No data']);
    die('No data found!');
}

// Khoi tao cac bien
$gateway = $data->gateway;
$transaction_date = $data->transactionDate;
$account_number = $data->accountNumber;
$sub_account = $data->subAccount;

$transfer_type = $data->transferType;
$transfer_amount = $data->transferAmount;
$accumulated = $data->accumulated;

$code = $data->code;
$transaction_content = $data->content;
$reference_number = $data->referenceCode;
$body = $data->description;

$amount_in = 0;
$amount_out = 0;

// Kiem tra giao dich tien vao hay tien ra
if ($transfer_type == "in") {
    $amount_in = $transfer_amount;
} elseif ($transfer_type == "out") {
    $amount_out = $transfer_amount;
}

// Chống SQL injection
$stmt = $conn->prepare("INSERT INTO tb_transactions (gateway, transaction_date, account_number, sub_account, amount_in, amount_out, accumulated, code, transaction_content, reference_number, body) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssdddssss", $gateway, $transaction_date, $account_number, $sub_account, $amount_in, $amount_out, $accumulated, $code, $transaction_content, $reference_number, $body);

// Chay query de luu giao dich vao CSDL
if ($stmt->execute()) {
    // echo json_encode(['success'=>TRUE]);
} else {
    error_log('MySQL insert error: ' . $stmt->error);
}
$stmt->close();

// Tách mã đơn hàng

// Biểu thức regex để khớp với mã đơn hàng
$regex = '/DH(\d+)/';

// Sử dụng preg_match để khớp regex với chuỗi nội dung chuyển tiền
if (!preg_match($regex, $transaction_content, $matches)) {
    echo json_encode(['success' => false, 'message' => 'Không tìm thấy mã đơn hàng']);
    die();
}

// Lấy mã đơn hàng từ kết quả khớp
$pay_order_id = $matches[1];

// Tìm đơn hàng với mã đơn hàng và số tiền tương ứng (chống SQL injection)
$stmt = $conn->prepare("SELECT * FROM tb_orders WHERE id = ? AND total = ? AND payment_status = 'Unpaid'");
$stmt->bind_param("id", $pay_order_id, $amount_in);
$stmt->execute();
$result = $stmt->get_result();

// Nếu không tìm thấy đơn hàng
if (!$result || $result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Order not found. Order_id ' . $pay_order_id]);
    $stmt->close();
    die();
} else {
    $stmt->close();
    // Tìm thấy đơn hàng, update trạng thái (chống SQL injection)
    $stmt2 = $conn->prepare("UPDATE tb_orders SET payment_status = 'Paid' WHERE id = ?");
    $stmt2->bind_param("i", $pay_order_id);
    $stmt2->execute();
    $stmt2->close();
    echo json_encode(['success' => true]);

}
